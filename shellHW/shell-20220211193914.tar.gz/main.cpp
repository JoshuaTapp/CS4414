#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <sys/stat.h> 
#include <fcntl.h>


std::vector<std::string> opers = { "<", ">", "|"}; 

struct cmd {
    std::vector<char*> cmdList;
    char* readPath = NULL; 
    char* writePath = NULL;
};

int validCommand(std::vector<std::string> &tokens) {
    int words = 0;
    int redir = 0;
    int redirFlag = 0;
    for(auto it = tokens.begin(); it != tokens.end(); ++it) {
        for(auto &str : opers) {
            if(*it == str){
                if(redirFlag != 0) return -1;
                redir++;
                redirFlag = 1;
                goto foundOp; // if we found an operator, break out of inner loop into the outer loop
            }
        }
        redirFlag = 0; // either had redir and have word, or 2+ words in row. either way, reset flag.
        words++;
        foundOp:
            continue;
    }

    if((words - redir) < 1) return -1;  // error if more redirs than words, need at least 1 more (command)
    if(redirFlag == 1) return -1; // redir with no following word, error.
    for(auto &str : opers){
        if(tokens.back() == str) return -1;
    }
    return 0;

}

void parseTokens(std::vector<std::string> &tokens, cmd &currentCMD){
    //std::cout << "Inside parseTokens:\t"; 
    for(auto it = tokens.begin(); it != tokens.end(); ++it) {
            // INPUT
            if(*it == "<") {
                // add the file path to our variable
                ++it;
                auto path = &(*it);
                currentCMD.readPath = const_cast<char*>((path->c_str()));
                //std::cout << "readPath: " << currentCMD.readPath << "\t";
            }
            // OUTPUT
            else if(*it == ">") {
                ++it;
                auto path = &(*it);
                // add the file path to our variable
                currentCMD.writePath = const_cast<char*>((path->c_str()));
                //std::cout << "writePath: " << currentCMD.writePath << "\t";
            }
            // handling PIPING
            else if(*it == "|") {
                // NEED TO IMPLEMENT
            }
            else {
                // add command or arg to cmdList
                //std::cout << "adding command/arg: ";
                auto arg = &(*it);
                currentCMD.cmdList.push_back(const_cast<char*>((arg->c_str())));
                //std::cout << currentCMD.cmdList.back() << " ";
            }
    }
    // Add last element to cmdList. BC the for loop above handles the case when its a file path
    //currentCMD.cmdList.push_back(const_cast<char*>((tokens.back()).c_str()));
    // ADD nullptr to the last index of cmdList
    currentCMD.cmdList.push_back( (char*) NULL);
    //std::cout << "\nparseTokens Finished!\n";
    /*
    for(int i = 0; i < (int) currentCMD.cmdList.size(); i++) {
        std::cout << currentCMD.cmdList.at(i) << " ";
    }
    std::cout << "\nEND OF parseTokens\n";
    */
}

void execCommand(std::vector<std::string> tokens){
    // fork a child to run the command
    pid_t pid;
    int read_fd = -1, write_fd = -1;
    int status;
    //int std_in = STDIN_FILENO, std_out = STDOUT_FILENO; 

    /*
        parseTokens modifies the cmdList, readPath, and writePath.
        These vars are used in executing and fd modification.
    */
    
    //std::cout << "readPath: " << currentCmds.readPath << "\twritePath: " << currentCmds.writePath << "\n";
    /*
        PIPING HANDLE:
            TODO
    */

    // FORK the process, else if block is child, else block is parent.
    // both have access to their own vars declared before fork()
    pid = fork();
    cmd currentCmds;
    //cmd *cmdPtr = &currentCmds;
    parseTokens(tokens, currentCmds);
    //std::cout << "cmdList Size: " << currentCmds.cmdList.size() << "\n";
    // handle failed fork
    if (pid < 0) {
        std::cerr << "fork failed in execCommand";
    }

    else if(pid == 0) {
        /*  The child runs the command given from the cmdList vector
            if execv fails, will print to std::cerr the corresponding error message */
        //if(currentCmds.cmdList.at(0) == (char*) "exit") exit(0);

        /* 
            REDIRECTION: 
                if readPath is present, open file, change STDIN to that file,
                and close the original file.

                do same for writePath.
        */
        //std::cout << 
        //std::cout << "STILL WORKING RIGHT BEFORE REDIRECT: " << pid << "\n";

       // READ REDIRECT
       
        if(currentCmds.readPath != (char*) NULL) {
            read_fd = open(currentCmds.readPath, O_RDONLY, 0666);
            if(read_fd != -1) {
                dup2(read_fd, 0);
                close(read_fd);
            }
            else {
                std::cerr << "FILE" << read_fd << "DOES NOT EXIST\n";
            }
        }

        // WRITE REDIRECT
        if(currentCmds.writePath != (char*) NULL) {
           write_fd = open(currentCmds.writePath, O_WRONLY | O_CREAT | O_TRUNC, 0666);
           if(write_fd != -1) {
               dup2(write_fd, 1);
               close(write_fd);
           }
           else{
               std::cerr << "DIRECTORY FOR " << write_fd << "DOES NOT EXIST\n";
           }
       }
       
        //std::string ch = currentCmds.cmdList.front();
        //std::cout << "STILL WORKING RIGHT BEFORE EXECV: " << pid << "\n";
        //std::cout << currentCmds.cmdList[0] << "\n";
        for(auto &c : currentCmds.cmdList ) {
            std::cout << c << " ";
        }
        if(execv( ((const char*) (currentCmds.cmdList.front())), currentCmds.cmdList.data() ) < 0) {
            std::cerr << "EXECV FAILED||";
            std::perror(currentCmds.cmdList.front());
           // for(std::vector<char*>::iterator itr=currentCmds.cmdList.begin(); itr!=currentCmds.cmdList.end(); ++itr) std::cout << *itr << " ";
            std::cout << "exit status: " << status/256 << "\n";
        }
    }
    // have the parent wait for the child to complete
    else {
        waitpid(pid, &status, 0); // w = child ID from wait
        for(auto &c : tokens ) std::cout << c << " "; 
        std::cout << "exit status: " << status/256 << "\n";
    }
}

void parse_and_run_command(const std::string &command) {
    /* TODO: Implement this. */
    /* Note that this is not the correct way to test for the exit command.
       For example the command "   exit  " should also exit your shell.
     */
    const std::string whitespace = " \t\f\v\n\r";
    
    std::vector<std::string> tokens;
    std::istringstream s(command);
    std::string token;
    std::vector<char*> char_tokens; 
    
    // tokenize using stringstream b/c its nice
    while (s >> token) {
        tokens.push_back(token);
    }

    
    // handle if the line has no input
    // if(tokens.size() == 0) exit(0);
    // handle exit command
    if (command == "exit") {
        exit(0);
    }
    if(validCommand(tokens) != 0) {
         std::cerr << "Invalid command";
         for(auto c : tokens) {
             std::cout << c << " "; 
         }
        std::cout << "\texit status: " << 255 << "\n";
        goto skip;
    }
    execCommand(tokens);
    skip:
    tokens.clear();

    //std::cerr << "Not implemented.\n";
}

int main(void) {
    std::string command;
    std::cout << "> ";
    while (std::getline(std::cin, command)) {
        
        parse_and_run_command(command);
        std::cout << "> ";
    }
    return 0;
}
